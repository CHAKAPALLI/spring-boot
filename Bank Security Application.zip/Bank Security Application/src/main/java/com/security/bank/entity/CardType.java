package com.security.bank.entity;

public enum CardType {
    DEBIT_CLASSIC,
    DEBIT_GLOBAL,
    CREDIT_PREMIUM,
    CREDIT_MASTER

}
