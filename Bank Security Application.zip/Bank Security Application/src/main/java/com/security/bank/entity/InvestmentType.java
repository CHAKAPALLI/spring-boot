package com.security.bank.entity;

public enum InvestmentType {
    GOLD,
    STOCKS,
    MUTUAL_FUND,
    FIXED_DEPOSITS
}
