package com.cn.trademaster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TradeMasterApplication {

	public static void main(String[] args) {
		SpringApplication.run(TradeMasterApplication.class, args);
	}

}
