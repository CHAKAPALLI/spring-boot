package com.CN.PharmaLink.service;

import com.CN.PharmaLink.communicator.StoreFinderCommunicator;
import com.CN.PharmaLink.dto.MedicalStoreDto;
import com.CN.PharmaLink.dto.UserRequest;
import com.CN.PharmaLink.model.User;
import com.CN.PharmaLink.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

	private final UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private StoreFinderCommunicator storeFinderCommunicator;

	public UserService(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	public void createUser(UserRequest userRequest) {
		String encodedPassword = passwordEncoder.encode(userRequest.getPassword());
		User user = new User();
		user.setUsername(userRequest.getUsername());
		user.setPassword(encodedPassword);
		user.setYCoordinate(userRequest.getYCoordinate());
		user.setXCoordinate(userRequest.getXCoordinate());
		userRepository.save(user);
	}

	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	public List<MedicalStoreDto> getNearestMedicalStores(Long userId, Long distance, String token) {
		return storeFinderCommunicator.getNearestMedicalStores(userId, distance, token);
	}

	public List<MedicalStoreDto> getMedicalStoresWithMedicine(String medicine, String token) {
		return storeFinderCommunicator.getMedicalStoresWithMedicine(medicine, token);
	}
}
