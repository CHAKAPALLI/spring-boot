package com.CN.PharmaLink.communicator;

import com.CN.PharmaLink.dto.MedicalStoreDto;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.List;

@Service
public class StoreFinderCommunicator {

    private final RestTemplate restTemplate;

    public StoreFinderCommunicator(RestTemplateBuilder restTemplateBuilder) {
        this.restTemplate = restTemplateBuilder.build();
    }

    public List<MedicalStoreDto> getNearestMedicalStores(Long userId, Long distance, String jwtToken)
    {
        String url ="http://localhost:8081/store/getNearestStores/" + userId + "/" + distance;
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + jwtToken);

        HttpEntity<?> requestEntity = new HttpEntity<>(headers);

        // Make the REST call to retrieve ratings
        ResponseEntity<List<MedicalStoreDto>> ratingResponse = restTemplate.exchange(
                url,
                HttpMethod.GET,
                requestEntity,
                new ParameterizedTypeReference<>() {
                }
        );

        return ratingResponse.getBody();
    }

    public List<MedicalStoreDto> getMedicalStoresWithMedicine(String medicine, String jwtToken)
    {
        String url ="http://localhost:8081/store/getStoresWithMedicine/" + medicine;
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + jwtToken);
        HttpEntity<?> requestEntity = new HttpEntity<>(headers);

        // Make the REST call to retrieve ratings
        ResponseEntity<List<MedicalStoreDto>> ratingResponse = restTemplate.exchange(
                url,
                HttpMethod.GET,
                requestEntity,
                new ParameterizedTypeReference<>() {
                }
        );
        return ratingResponse.getBody();
    }
}
