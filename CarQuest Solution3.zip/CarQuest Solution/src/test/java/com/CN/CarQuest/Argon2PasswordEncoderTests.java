package com.CN.CarQuest;

import com.CN.CarQuest.config.CarSecurityConfig;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.argon2.Argon2PasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootTest
@DisplayName("Testing Config Layer for CarQuest Application")
class Argon2PasswordEncoderTests {

	@Autowired
	private CarSecurityConfig carSecurityConfig;

	@Test
	@DisplayName("Testing config layer for Pbkdf2PasswordEncoder")
	public void testPasswordEncoder() {
		PasswordEncoder passwordEncoder = carSecurityConfig.passwordEncoder();
		Assertions.assertNotNull(passwordEncoder,"carSecurityConfig.passwordEncoder() bean returned null value.");
		Assertions.assertInstanceOf(Argon2PasswordEncoder.class, passwordEncoder, "The given instance do not match with Argon2PasswordEncoder.");
	}

}
