package com.CN.CarQuest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarQuestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarQuestApplication.class, args);
	}

}
