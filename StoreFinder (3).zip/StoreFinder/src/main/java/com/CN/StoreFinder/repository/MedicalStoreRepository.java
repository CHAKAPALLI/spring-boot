package com.CN.StoreFinder.repository;

import com.CN.StoreFinder.model.MedicalStore;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MedicalStoreRepository extends JpaRepository<MedicalStore, Long> {

}
